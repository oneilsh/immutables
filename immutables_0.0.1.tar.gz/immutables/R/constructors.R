
##############################
## Node type definitions
##############################

# generic node type
# stores arbitrary child elements in a list; base for Node2/Node3
# Runtime: O(n) worst-case in relevant input/subtree size.
Node(...) %::% ... : list
Node(...) %as% { 
  res <- list(...)
  return(res)
}

# Node2 and Node3 node types
# represent internal nodes with 2 or 3 children
# Runtime: O(n) worst-case in relevant input/subtree size.
Node2(x, y) %::% a : a : list
Node2(x, y) %as% Node(x, y)

# Runtime: O(n) worst-case in relevant input/subtree size.
Node3(x, y, z) %::% a : a : a : list
Node3(x, y, z) %as% Node(x, y, z)


# Runtime: O(n) worst-case in relevant input/subtree size.
FingerTree() %::% FingerTree
FingerTree() %as% Empty()


# basic constructor for inheriting
# internal convenience for creating tree records
# Runtime: O(n) worst-case in relevant input/subtree size.
FingerTree(...) %::% ... : list
FingerTree(...) %as% {
  list(...)
}

# empty node type
# represents an empty tree
# Runtime: O(n) worst-case in relevant input/subtree size.
Empty() %::% FingerTree
Empty() %as% FingerTree(NULL)


# single-element node type
# represents a tree with exactly one element
# Runtime: O(n) worst-case in relevant input/subtree size.
Single(x) %::% . : FingerTree
Single(x) %as% FingerTree(x)

# digits are like nodes, but they allow 1 to 4 elements
# used as prefix/suffix containers in Deep
# Runtime: O(n) worst-case in relevant input/subtree size.
Digit(...) %::% ... : list
Digit(...) %as% {
  list(...)
}

# Deep is the main data type, with a prefix (digit), middle (fingertree), and suffix (digit)
# Runtime: O(n) worst-case in relevant input/subtree size.
Deep(prefix, middle, suffix) %::% Digit : FingerTree : Digit : FingerTree
Deep(prefix, middle, suffix) %as% {
  FingerTree(prefix = prefix, middle = middle, suffix = suffix)   
}
