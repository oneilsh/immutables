#' immutables
#'
#' Monoid-annotated 2-3 finger trees.
#'
#' @keywords internal
#' @import lambda.r
#' @importFrom Rcpp evalCpp
#' @useDynLib immutables, .registration = TRUE
"_PACKAGE"
