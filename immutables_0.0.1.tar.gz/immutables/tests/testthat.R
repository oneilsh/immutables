library(testthat)
library(immutables)

test_check("immutables")
